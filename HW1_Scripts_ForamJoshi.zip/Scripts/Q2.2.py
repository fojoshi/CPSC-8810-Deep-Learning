import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds


# In[2]:


mnist_data = tfds.load(name="mnist", split="train").repeat()
mnist_data = mnist_data.batch(64).prefetch(10)

# In[7]:


X_input = tf.placeholder(tf.uint8, shape = [None, 28, 28, 1], name = 'Input')
X_input=X_input/255
flatten=tf.layers.flatten(X_input)


y_o = tf.placeholder(tf.int64, shape = [None, 1], name = 'True_Output')
Y_one_hot_encoder=tf.one_hot(y_o,10)

lr = tf.placeholder(tf.float32, shape = [], name = 'lr')

w0 = tf.Variable(tf.truncated_normal([784, 64], stddev=0.01))
b0 = tf.Variable(tf.ones([64])/1)

w1 = tf.Variable(tf.truncated_normal([64, 64], stddev=0.01))
b1 = tf.Variable(tf.ones([64])/1)

w2 = tf.Variable(tf.truncated_normal([64, 10], stddev=0.01))
b2 = tf.Variable(tf.ones([10])/1)

y0 = tf.nn.relu( tf.matmul(flatten,w0) + b0, name = 'first')
# ?, 1 * 1, 32 => ?, 32

y1 = tf.nn.relu(tf.matmul(y0,w1) + b1,name = 'second' )
# ?, 32 * 32, 64 => ?, 64


y_pred = tf.nn.relu(tf.add(tf.matmul(y1, w2), b2,name = 'output'))


# In[8]:

correct_prediction = tf.equal(tf.argmax(y_pred, 1), tf.squeeze(y_o))
#calculate accuracy across all the given images and average them out.
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(
        labels=Y_one_hot_encoder, logits=y_pred
        ))
opt= tf.train.AdamOptimizer(0.001)
gradient=opt.compute_gradients(loss)
train_step=opt.apply_gradients(gradient)


# In[9]:


sess = tf.Session()
sess.run(tf.global_variables_initializer())


# In[10]:


def norm(g, p=2):
        s = 0
        for i in g:
            for v in i[0]:
                s += np.sum(v**p)
        return s ** (1/p)
model_loss=[]
grad_norm=[]
trainable_variable=[]
batch_counter=0
batch_size=64
epochs = 10001
try:
    print("Please press control C to stop training early")
    for i, batch in enumerate(tfds.as_numpy(mnist_data.take(epochs))):
        miniBatchX = batch["image"]
        miniBatchY = batch["label"]
        miniBatchY = miniBatchY[:, np.newaxis]
        _, grad_f, l, acc = sess.run(fetches = [train_step, gradient, loss, accuracy], feed_dict = {X_input : miniBatchX,
                                                                                     y_o : miniBatchY})
        grad_norm.append(norm(grad_f))
        model_loss.append(l)
        if i % 100 == 0:
            print("Epochs: {}/{}, Loss: {}, Accuracy: {}, Grad Norm: {}".format(i, epochs - 1, l, acc, grad_norm[-1]))

except KeyBoardInterrupt:
    pass
# In[11]:
finally:

    fig,(p1, p2) = plt.subplots(2, sharex=True)
    fig.suptitle('MNIST')
    p1.set(ylabel='Grad norm')
    p2.set(xlabel='Epochs', ylabel='Loss')
    p1.plot(grad_norm)
    p2.plot(model_loss)
    plt.show()
