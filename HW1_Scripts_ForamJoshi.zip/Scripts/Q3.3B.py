import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds

mnist_data = tfds.load(name="mnist", split="train").repeat()
mnist_data = mnist_data.batch(256).prefetch(10)

mnist_train_check_data = tfds.load(name="mnist", split="train").repeat()
mnist_train_check_data = mnist_train_check_data.batch(2048)
for check in tfds.as_numpy(mnist_train_check_data.take(1)):
    X_train = check["image"]
    Y_train = check["label"]
Y_train = Y_train[:, np.newaxis]


mnist_test_data = tfds.load(name="mnist", split="test")
mnist_test_data = mnist_test_data.batch(2048)
for test in tfds.as_numpy(mnist_test_data.take(1)):
    X_test = test["image"]
    Y_test = test["label"]
Y_test = Y_test[:, np.newaxis]


def dnn_func(X,hidden_layer_shapes=[[784,128], [128,10]]):
    w = []
    b = []
    hidden = []
    for i in hidden_layer_shapes:
        w.append(tf.Variable(tf.truncated_normal(i, stddev=0.01)))
        b.append(tf.Variable(tf.ones([i[1]])) )
    hidden.append(tf.nn.sigmoid(tf.matmul(X, w[0]) + b[0]))
    for k in range(1, len(w)-1):
        hidden.append(tf.nn.sigmoid(tf.matmul(hidden[k - 1], w[k]) + b[k]))
    y_pred = tf.matmul(hidden[-1],w[-1]) + b[-1]

    return w, b, hidden, y_pred


# In[15]:

sess = tf.Session()
X = tf.placeholder(tf.uint8, shape = [None, 28,28,1], name = 'Input')
flatten=tf.layers.flatten(X)
X_ = flatten/255

y_o = tf.placeholder(tf.uint8, shape = [None, 1], name = 'True_Output')
Y_one_hot_encoder=tf.one_hot(y_o,10)

lrate = tf.placeholder(tf.float32, shape = [], name = 'lr')
w, b, hidden, y_pred = dnn_func(X_)
loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(
    labels=Y_one_hot_encoder, logits=y_pred ))
correct_prediction = tf.equal(tf.cast(tf.argmax(y_pred, 1),tf.uint8), tf.squeeze(y_o))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
sensitivity = tf.norm(tf.gradients(loss, X_))

train_step= tf.train.AdamOptimizer(lrate).minimize(loss)


sess.run(tf.global_variables_initializer())

rates_trials = [0.05, 0.02, 0.01, 0.005, 0.002, 0.001, 0.0001, 0.00005]

epochs = 501
losses = []
accs = []
valaccs = []
valls = []
snst = []

for lr in rates_trials:
    print("Using learning rate: {}".format(lr))
    for i, batch in enumerate(tfds.as_numpy(mnist_data.take(epochs))):
        miniBatchX = batch["image"]
        miniBatchY = batch["label"]
        miniBatchY = miniBatchY[:, np.newaxis]
        _, lr1,acc_train1 = sess.run(fetches = [train_step, loss, accuracy], feed_dict = {X : miniBatchX,
                                                               y_o : miniBatchY, lrate : lr})
        if i % 100 == 0:
            print("Epochs:{}, Loss: {}, Accuracy:{}".format(i, lr1, acc_train1))

    sen, l, acc = sess.run(fetches = [sensitivity, loss, accuracy], feed_dict = {X : X_train,
                                                           y_o : Y_train})

    val_loss, val_accuracy = sess.run(fetches = [loss, accuracy], feed_dict = {X : X_test,
                                                           y_o : Y_test})
    snst.append(sen)
    losses.append(l)
    valaccs.append(val_accuracy)
    valls.append(val_loss)
    accs.append(acc)

fig, axs = plt.subplots(3, 1, constrained_layout=True)
ax1, = axs[0].plot(-np.log(rates_trials), np.log(losses), 'b-')
ax2, = axs[0].plot(-np.log(rates_trials), np.log(valls), 'r-')
axs[0].legend([ax1, ax2], ['Train', 'Validation'])
axs[0].set_ylabel("Loss (Log Scale)")
axs[0].set_xlabel("Learning Rates ( - Log )")

ax1, = axs[1].plot(rates_trials, accs, 'b-')
ax2, = axs[1].plot(rates_trials, valaccs, 'r-')
axs[1].set_ylabel("Accuracies")
axs[1].set_xlabel("Learning Rates ( - Log )")

ax3, = axs[2].plot(-np.log10(rates_trials), snst, 'g--')
axs[2].set_ylabel("Sensitivity")
axs[2].set_xlabel("Learning Rates ( - Log )")
plt.show()
