
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf


# In[2]:


min_val=0
max_val=1
data_size=10000


# In[3]:


x = np.linspace(min_val, max_val, data_size)
np.random.shuffle(x)
x=x[:,np.newaxis]
y = (np.cos(3*np.pi*x)/2 + 0.5)
# y = (np.cos(6*np.pi*x))*np.exp(-x) /2 + 0.375
plt.title("cos3ℼx/2+0.5")
plt.plot(x, y, 'r.');
plt.show()


# In[4]:


tf.reset_default_graph()
sess = tf.Session()


# In[6]:


# Model 1
X = tf.placeholder(tf.float32, shape = [None, 1], name = 'Input')
y_o = tf.placeholder(tf.float32, shape = [None, 1], name = 'True_Output')
lr = tf.placeholder(tf.float32, shape = [], name = 'lr')

w0 = tf.Variable(tf.truncated_normal([1, 12], stddev=0.01))
b0 = tf.Variable(tf.ones([12])/1)

w1 = tf.Variable(tf.truncated_normal([12, 4], stddev=0.01))
b1 = tf.Variable(tf.ones([4])/1)

w2 = tf.Variable(tf.truncated_normal([4, 1], stddev=0.01))
b2 = tf.Variable(tf.ones([1])/1)

y0 = tf.nn.sigmoid( tf.matmul(X,w0) + b0)
y1 = tf.nn.sigmoid(tf.matmul(y0,w1) + b1)
y_pred = tf.nn.sigmoid(tf.add(tf.matmul(y1, w2), b2,name = 'output'))

loss= tf.reduce_mean((y_o - y_pred) ** 2)
train_step = tf.train.AdamOptimizer(lr).minimize(loss)

print("Number of parameters (Model1 - 2 hidden layers):", np.sum([np.prod(v.get_shape().as_list()) for v in tf.trainable_variables()]))
sess.run(tf.global_variables_initializer())


# In[7]:


model_loss1=[]
for i in range(2000):
    _, l = sess.run(fetches = [train_step, loss], feed_dict = {X : x, y_o : y, lr : 0.1})
    model_loss1.append(l)
    if i % 100 == 0:
        print("Epochs: {}, Loss: {}".format(i, l))


# In[8]:


y_model1 = sess.run(fetches = y_pred, feed_dict = {X : x})


# In[9]:


tf.reset_default_graph()
sess = tf.Session()

#Model 2
X = tf.placeholder(tf.float32, shape = [None, 1], name = 'Input')
y_o = tf.placeholder(tf.float32, shape = [None, 1], name = 'True_Output')
lr = tf.placeholder(tf.float32, shape = [], name = 'lr')

w0 = tf.Variable(tf.truncated_normal([1, 10], stddev=0.01))
b0 = tf.Variable(tf.ones([10])/1)

w1 = tf.Variable(tf.truncated_normal([10, 5], stddev=0.01))
b1 = tf.Variable(tf.ones([5])/1)

w2 = tf.Variable(tf.truncated_normal([5, 1], stddev=0.01))
b2 = tf.Variable(tf.ones([1])/1)

y0 = tf.nn.sigmoid( tf.matmul(X,w0) + b0)
y1 = tf.nn.sigmoid(tf.matmul(y0,w1) + b1)
y_pred = tf.nn.sigmoid(tf.add(tf.matmul(y1, w2), b2,name = 'output'))

loss= tf.reduce_mean((y_o - y_pred) ** 2)
train_step = tf.train.AdamOptimizer(lr).minimize(loss)

print("Number of parameters (Model2 - 2 hidden layers):", np.sum([np.prod(v.get_shape().as_list()) for v in tf.trainable_variables()]))

sess.run(tf.global_variables_initializer())


# In[10]:


model_loss2=[]
for i in range(2000):
    _, l = sess.run(fetches = [train_step, loss], feed_dict = {X : x, y_o : y, lr : 0.1})
    model_loss2.append(l)
    if i % 100 == 0:
        print("Epochs: {}, Loss: {}".format(i, l))


# In[11]:


y_model2 = sess.run(fetches = y_pred, feed_dict = {X : x})


# In[12]:


plt.figure(figsize=(10,10))
ax1, = plt.plot(x, y, "bo",label='x')
ax2, = plt.plot(x, y_model1, "y.",label='M1')
ax3, = plt.plot(x, y_model2, "r.",label='M2')

plt.ylabel("Value")
plt.xlabel("X")
plt.title("Dataset")

plt.legend([ax1, ax2, ax3], ["True Y", "Model1", "Model2"])
plt.show()


# In[13]:


plt.figure(figsize=(10,10))
ax1,=plt.plot(model_loss1, "y-")
ax2,=plt.plot(model_loss2, "r-")
plt.ylabel("Loss")
plt.xlabel("Epochs")
plt.title("Model_loss")
plt.legend([ax1, ax2], ["Model1", "Model2"])
plt.show()

