import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

min_val=0
max_val=1
data_size=10000


# In[13]:


x = np.linspace(min_val, max_val, data_size)
np.random.shuffle(x)
x=x[:,np.newaxis]
y = (np.cos(3*np.pi*x)/2 + 0.5)
plt.title("cos3ℼx/2+0.5")
plt.plot(x, y, 'r.');
plt.show()

tf.reset_default_graph()
# Model 1
X = tf.placeholder(tf.float32, shape = [None, 1], name = 'Input')
y_o = tf.placeholder(tf.float32, shape = [None, 1], name = 'True_Output')
lr = tf.placeholder(tf.float32, shape = [], name = 'lr')

w0 = tf.Variable(tf.truncated_normal([1, 10], stddev=0.01))
b0 = tf.Variable(tf.ones([10])/1)

w1 = tf.Variable(tf.truncated_normal([10,8], stddev=0.01))
b1 = tf.Variable(tf.ones([8])/1)

w2 = tf.Variable(tf.truncated_normal([8, 1], stddev=0.01))
b2 = tf.Variable(tf.ones([1])/1)

y0 = tf.nn.sigmoid( tf.matmul(X,w0) + b0)
y1 = tf.nn.sigmoid(tf.matmul(y0,w1) + b1)
y_pred = (tf.add(tf.matmul(y1, w2), b2,name = 'output'))

loss = tf.reduce_mean((y_o - y_pred) ** 2)
gradient=tf.gradients(loss, tf.trainable_variables())
hessian=tf.squeeze(tf.squeeze(tf.hessians(loss, w2)[0], -1), -2)
train_step=tf.train.AdamOptimizer(0.1).minimize(loss)


# In[16]:


sess = tf.Session()
sess.run(tf.global_variables_initializer())


# In[17]:


def norm(g, p=2):
        s = 0
        for i in g:
            for v in i:
                s += np.sum(v**p)
        return s ** (1/p)
model_loss=[]
minimal_ratios = []
grad_norm = []
for i in range(1000):
    _, grad_f, l = sess.run(fetches = [train_step, gradient, loss], feed_dict = {X : x, y_o : y})
    model_loss.append(l)
    grad_n = norm(grad_f)
    grad_norm.append(grad_n)
    if i % 100 == 0:
        print("Loss:{}".format(l))


# In[19]:


fig,(p1, p2) = plt.subplots(2, sharex=True)

fig.suptitle('cos function')
p1.set( ylabel='Grad norm')
p2.set(xlabel='Epochs', ylabel='Log Loss')
p1.plot(grad_norm)
p2.plot(np.log(model_loss))
plt.show()
