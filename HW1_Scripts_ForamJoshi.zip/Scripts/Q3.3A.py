import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds

mnist_data = tfds.load(name="mnist", split="train").repeat()
mnist_data = mnist_data.batch(256).prefetch(10)

mnist_train_check_data = tfds.load(name="mnist", split="train").repeat()
mnist_train_check_data = mnist_train_check_data.batch(2048)
for check in tfds.as_numpy(mnist_train_check_data.take(1)):
    X_train = check["image"]
    Y_train = check["label"]
Y_train = Y_train[:, np.newaxis]


mnist_test_data = tfds.load(name="mnist", split="test")
mnist_test_data = mnist_test_data.batch(2048)
for test in tfds.as_numpy(mnist_test_data.take(1)):
    X_test = test["image"]
    Y_test = test["label"]
Y_test = Y_test[:, np.newaxis]


def dnn_func(X,hidden_layer_shapes=[[784,128], [128,10]]):
    w = []
    b = []
    hidden = []
    for i in hidden_layer_shapes:
        w.append(tf.Variable(tf.truncated_normal(i, stddev=0.01)))
        b.append(tf.Variable(tf.ones([i[1]])) )
    hidden.append(tf.nn.sigmoid(tf.matmul(X, w[0]) + b[0]))
    for k in range(1, len(w)-1):
        hidden.append(tf.nn.sigmoid(tf.matmul(hidden[k - 1], w[k]) + b[k]))
    y_pred = tf.matmul(hidden[-1],w[-1]) + b[-1]

    return w, b, hidden, y_pred


# In[15]:

sess1 = tf.Session()
sess2 = tf.Session()
sess3 = tf.Session()
X = tf.placeholder(tf.uint8, shape = [None, 28,28,1], name = 'Input')
X = X/255
flatten=tf.layers.flatten(X)
y_o = tf.placeholder(tf.uint8, shape = [None, 1], name = 'True_Output')
Y_one_hot_encoder=tf.one_hot(y_o,10)

lrate = tf.placeholder(tf.float32, shape = [], name = 'lr')
w, b, hidden, y_pred = dnn_func(flatten)
loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(
    labels=Y_one_hot_encoder, logits=y_pred ))
train_step= tf.train.AdamOptimizer(lrate).minimize(loss)
correct_prediction = tf.equal(tf.cast(tf.argmax(y_pred, 1),tf.uint8), tf.squeeze(y_o))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

weights_in_order = []
for wt, bi in zip(w, b):
    weights_in_order.append(wt)
    weights_in_order.append(bi)


sess1.run(tf.global_variables_initializer())
sess2.run(tf.global_variables_initializer())
#sess3.run(tf.global_variables_initializer())
epochs = 1201
print("Using lr: 0.005")
for i, batch in enumerate(tfds.as_numpy(mnist_data.take(epochs))):
    miniBatchX = batch["image"]
    miniBatchY = batch["label"]
    miniBatchY = miniBatchY[:, np.newaxis]
    _, lr1,acc_train1 = sess1.run(fetches = [train_step, loss, accuracy], feed_dict = {X : miniBatchX,
                                                           y_o : miniBatchY, lrate : 0.005})
    if i % 50 == 0:
        print("Epochs:{}, Loss: {}, Accuracy:{}".format(i, lr1, acc_train1))
weights1 = sess1.run(tf.trainable_variables())

print("Using lr: 0.0005")
for i, batch in enumerate(tfds.as_numpy(mnist_data.take(epochs))):
    miniBatchX = batch["image"]
    miniBatchY = batch["label"]
    miniBatchY = miniBatchY[:, np.newaxis]
    _, lr2, acc_train2 = sess2.run(fetches = [train_step, loss, accuracy], feed_dict = {X : miniBatchX,
                                                           y_o : miniBatchY, lrate : 0.0005})
    if i % 50 == 0:
        print("Epochs:{}, Loss: {}, Accuracy:{}".format(i, lr2, acc_train2))

weights2 = sess2.run(tf.trainable_variables())


loss3 = []
alphas = []
accuracy3 = []
val_acc3 = []
val_loss3 = []
alpha = -1
def interpolate(w1, w2, alpha=0.5):
    return (1 - alpha)*w1 + alpha * w2
weights_interpolated = []

while alpha <= 2:
    for w1, w2, variable in zip(weights1, weights2, weights_in_order):
        sess3.run(tf.assign(variable, interpolate(w1, w2, alpha)))

    ls3, acc_train_lr3 = sess3.run(fetches = [loss, accuracy], feed_dict = {X : X_train,
                                                       y_o : Y_train})
    val_ls3, acc_val_ls3 = sess3.run(fetches = [loss, accuracy], feed_dict = {X : X_test,
                                                       y_o : Y_test})

    alpha += 0.1
    loss3.append(ls3)
    accuracy3.append(acc_train_lr3)
    val_acc3.append(acc_val_ls3)
    val_loss3.append(val_ls3)
    alphas.append(alpha)


# In[38]:

ax1, = plt.plot(alphas, loss3)
ax2, = plt.plot(alphas, val_loss3, 'r--')
plt.legend([ax1, ax2], ["Train", "Test"])
plt.xlabel("alpha")
plt.ylabel("Loss")
plt.title("Loss vs alpha")
plt.show()


# In[39]:

ax1, = plt.plot(alphas, accuracy3)
ax2, = plt.plot(alphas, val_acc3, 'r--')
plt.legend([ax1, ax2], ["Train", "Test"])
plt.xlabel("alpha")
plt.ylabel("Accuracy")
plt.title("Accuracy vs alpha")
plt.show()
