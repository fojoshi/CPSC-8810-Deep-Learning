import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds


layer_shapes_trials = [
    [[784,64],[64,32],[32,10]],
    [[784, 4],[4, 4],[4, 10]],
    [[784,2],[2,2],[2,2],[2,10]],
    [[784,4],[4,4],[4,4],[4,10]],
    [[784,64],[64,32],[32,10]],
    [[784,8],[8,4],[4,10]],
    [[784,10],[10,10]],
    [[784,32],[32,10]],
    [[784,64],[64,10]],
    [[784,128],[128,10]]
]


# In[110]:

sess = tf.Session()


# In[111]:


def dnn_func(X,hidden_layer_shapes=[[1,8], [8,8], [8,1]]):
    print(hidden_layer_shapes)
    w = []
    b = []
    hidden = []
    for i in hidden_layer_shapes:
        w.append(tf.Variable(tf.truncated_normal(i, stddev=0.01)))
        b.append(tf.Variable(tf.ones([i[1]])))

    hidden.append(tf.nn.sigmoid(tf.matmul(X, w[0]) + b[0]))
    for k in range(1, len(w)-1):
        hidden.append(tf.nn.sigmoid(tf.matmul(hidden[k - 1], w[k]) + b[k]))
    y_pred = tf.matmul(hidden[-1],w[-1]) + b[-1]

    return w, b, hidden, y_pred


# In[112]:


model_losses=[]
parameters=[]
accuracies_test=[]
accuracies_train=[]
train_loss=[]
test_loss=[]

for layer_shape in layer_shapes_trials:
    tf.reset_default_graph()

    sess = tf.Session()

    mnist_data = tfds.load(name="mnist", split="train").repeat()
    mnist_data = mnist_data.batch(64).prefetch(10)

    mnist_test_data = tfds.load(name="mnist", split="test")
    mnist_test_data = mnist_test_data.batch(2048)
    for test in tfds.as_numpy(mnist_test_data.take(1)):
        X_test = test["image"]
        Y_test = test["label"]
    Y_test = Y_test[:, np.newaxis]

    X = tf.placeholder(tf.uint8, shape = [None, 28,28,1], name = 'Input')
    X = X/255
    flatten=tf.layers.flatten(X)
    y_o = tf.placeholder(tf.uint8, shape = [None, 1], name = 'True_Output')
    Y_one_hot_encoder=tf.one_hot(y_o,10)

    lr = tf.placeholder(tf.uint8, shape = [], name = 'lr')
    w, b, hidden, y_pred = dnn_func(flatten, layer_shape)

    loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(
        labels=Y_one_hot_encoder, logits=y_pred ))
    opt= tf.train.AdamOptimizer(0.001)
    gradient=opt.compute_gradients(loss)

    correct_prediction = tf.equal(tf.cast(tf.argmax(y_pred, 1),tf.uint8), tf.squeeze(y_o))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    train_step=opt.apply_gradients(gradient)
    sess.run(tf.global_variables_initializer())

    parameters.append(np.sum([np.prod(v.get_shape().as_list()) for v in tf.trainable_variables()]))
    epochs = 1001
    for i, batch in enumerate(tfds.as_numpy(mnist_data.take(epochs))):
        miniBatchX = batch["image"]
        miniBatchY = batch["label"]
        miniBatchY = miniBatchY[:, np.newaxis]
        _, l,acc_train = sess.run(fetches = [train_step, loss, accuracy], feed_dict = {X : miniBatchX,
                                                               y_o : miniBatchY, lr : 0.005})
        acc_test, val_loss = sess.run(fetches=[accuracy, loss],
                    feed_dict={X:X_test, y_o: Y_test})
        if i % 200 == 0:
            print("Epochs: {}/{}, Loss: {:.2f},Accuracy train: {:.2f},Accuracy test: {:.2f},Validation loss: {:.2f}".format(
                i, epochs, l, acc_train, acc_test, val_loss))

    model_losses.append(l)
    accuracies_train.append(acc_train)
    accuracies_test.append(acc_test)
    train_loss.append(l)
    test_loss.append(val_loss)







# In[115]:


ax1, = plt.plot(parameters,train_loss, "r^")
ax2, = plt.plot(parameters,test_loss, "g^")

plt.legend([ax1, ax2], ['train_loss', 'test_loss'])
plt.xlabel("No. of parameters")
plt.ylabel("loss")
plt.title("MNIST model loss")

# In[117]:

plt.figure()
ax1, = plt.plot(parameters,accuracies_train, "r^")
ax2, = plt.plot(parameters,accuracies_test, "g^")
plt.legend([ax1, ax2], ['train_acc', 'test_acc'])
plt.xlabel("No. of parameters")
plt.ylabel("Accuracy")
plt.title("MNIST accuracy")
plt.show()
