
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds


# In[2]:


mnist_data = tfds.load(name="mnist", split="train").repeat()
mnist_data = mnist_data.batch(64).prefetch(10)


# In[6]:

X_input = tf.placeholder(dtype=tf.uint8, shape=[None, 28, 28, 1], name="Input")
Y_true = tf.placeholder(dtype=tf.int64,shape= [None, 1], name="TrueLabels")
lr = tf.placeholder(tf.float32, shape = [], name = 'lr')
Y_one_hot_encoder=tf.one_hot(Y_true,10)
X_input=X_input/255  #Normalization

conv_1=tf.layers.Conv2D( filters=64,kernel_size=3,strides=1,name='layer_conv1')(X_input)
conv_relu_1=tf.nn.relu(conv_1)
maxpool_1=tf.nn.max_pool(conv_relu_1, ksize=2,strides=1,padding='SAME')
flatten_1=tf.layers.flatten(maxpool_1)
output=tf.layers.dense(flatten_1,10,name='layer_fc1') #The 10 is the number of output

correct_prediction = tf.equal(tf.argmax(output, 1), tf.squeeze(Y_true))
#calculate accuracy across all the given images and average them out.
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(
        labels=Y_one_hot_encoder, logits=output
        ))
opt= tf.train.AdamOptimizer(0.001)
gradient=opt.compute_gradients(loss)
train_step=opt.apply_gradients(gradient)


# In[7]:


sess = tf.Session()
sess.run(tf.global_variables_initializer())


# In[9]:


batch_size=0
model_loss=[]
accuracies=[]
epochs = 301
for i, batch in enumerate(tfds.as_numpy(mnist_data.take(epochs))):
        miniBatchX = batch["image"]
        miniBatchY = batch["label"]
        miniBatchY = miniBatchY[:, np.newaxis]
        _, loss_f, acc = sess.run(fetches=[train_step, loss, accuracy],
            feed_dict={X_input:miniBatchX, Y_true: miniBatchY,lr: 0.01})
        model_loss.append(loss_f)
        accuracies.append(acc)
        if i % 100 == 0:
            print("Epochs: {}/{}, Loss: {},Accuracy: {}".format(i, epochs-1, loss_f, acc))



# In[12]:


#plt.plot(model_loss, color='black');
plt.figure(figsize=(8,8))
plt.plot(model_loss, "ro")
plt.xlabel("Epochs")
plt.ylabel("Train loss")
plt.title("MNIST CNN")

plt.figure(figsize=(8,8))
plt.plot(accuracies[:250], "r")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.title("MNIST CNN")
plt.show()
