import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds
from sklearn.model_selection import train_test_split


# In[2]:


dataset = tfds.load(name="mnist", split="train")


# In[3]:


mnist = tfds.as_numpy(dataset,graph=None)


# In[5]:


X = []
Y = []

print("Converting Dataset to Numpy")
count = 1
for i in mnist:
    count += 1
    X.append(i['image'])
    Y.append(i['label'])
    if count % 1000 == 0:
        print("{}/60000 done.".format(count))

X= np.array(X)
Y = np.array(Y)
Y = Y[:,np.newaxis]
np.random.shuffle(Y)


# In[6]:


X_train, X_test, Y_train, Y_test = train_test_split( X, Y, test_size=0.3)


# In[7]:


tf.reset_default_graph()

X_input = tf.placeholder(dtype=tf.uint8, shape=[None, 28, 28, 1], name="Input")
Y_true = tf.placeholder(dtype=tf.int64,shape= [None, 1], name="TrueLabels")
lr = tf.placeholder(tf.float32, shape = [], name = 'lr')
Y_one_hot_encoder=tf.one_hot(Y_true,10)
X_input=X_input/255  #Normalization

conv_1=tf.layers.Conv2D( filters=64,kernel_size=3,strides=1,name='layer_conv1')(X_input)
conv_relu_1=tf.nn.relu(conv_1)
maxpool_1=tf.nn.max_pool(conv_relu_1, ksize=2,strides=1,padding='SAME')
flatten_1=tf.layers.flatten(maxpool_1)
output=tf.layers.dense(flatten_1,10,name='layer_fc1') #The 10 is the number of output

correct_prediction = tf.equal(tf.argmax(output, 1), tf.squeeze(Y_true))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(
        labels=Y_one_hot_encoder, logits=output ))
opt= tf.train.AdamOptimizer(0.001)
gradient=opt.compute_gradients(loss)
train_step=opt.apply_gradients(gradient)


# In[10]:


sess = tf.Session()
sess.run(tf.global_variables_initializer())


# In[13]:


batch_size=0
train_loss=[]
test_loss=[]
accuracies_test=[]
accuracies_train=[]

for epoch in range(500):
    _, loss_f, acc_train = sess.run(fetches=[train_step, loss, accuracy],
            feed_dict={X_input:X_train[batch_size:batch_size+100], Y_true: Y_train[batch_size:batch_size+100]})
    if epoch%20 == 0:
        acc_test, val_loss = sess.run(fetches=[accuracy, loss],
                feed_dict={X_input:X_test, Y_true: Y_test})

        batch_size=batch_size+100

        if (batch_size >= len(X_train)):
            batch_size = 0
        train_loss.append(loss_f)
        test_loss.append(val_loss)
        accuracies_train.append(acc_train)
        accuracies_test.append(acc_test)
    if epoch % 100 == 0:
        print("Epochs: {}/500, Loss: {:.2f},Accuracy train: {:.2f},Accuracy test: {:.2f},Validation loss: {:.2f}".format(epoch, loss_f, acc_train,acc_test,val_loss))



# In[12]:


plt.figure(figsize=(8,8))
ax1, = plt.plot(np.log(train_loss), "r-")
ax2, = plt.plot(np.log(test_loss), "g-")
plt.legend([ax1, ax2], ['train_loss', 'test_loss'])

plt.xlabel("Epochs")
plt.ylabel("Log loss")
plt.title("MNIST CNN")
plt.show()
