import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds
from sklearn.decomposition import PCA


# In[2]:

mnist_data = tfds.load(name="mnist", split="train").repeat()
mnist_data = mnist_data.batch(64).prefetch(10)
# In[4]:

X_input = tf.placeholder(tf.uint8, shape = [None, 28, 28, 1], name = 'Input')
X_input=X_input/255
flatten=tf.layers.flatten(X_input)


y_o = tf.placeholder(tf.int64, shape = [None, 1], name = 'True_Output')
Y_one_hot_encoder=tf.one_hot(y_o,10)

lr = tf.placeholder(tf.float32, shape = [], name = 'lr')

w0 = tf.Variable(tf.truncated_normal([784, 64], stddev=0.1))
b0 = tf.Variable(tf.ones([64])/1)

w1 = tf.Variable(tf.truncated_normal([64, 64], stddev=0.01))
b1 = tf.Variable(tf.ones([64])/1)

w2 = tf.Variable(tf.truncated_normal([64, 10], stddev=0.01))
b2 = tf.Variable(tf.ones([10])/1)

y0 = tf.nn.relu( tf.matmul(flatten,w0) + b0, name = 'first')
# ?, 1 * 1, 32 => ?, 32

y1 = tf.nn.relu(tf.matmul(y0,w1) + b1,name = 'second' )
# ?, 32 * 32, 64 => ?, 64


y_pred = tf.nn.relu(tf.add(tf.matmul(y1, w2), b2,name = 'output'))
correct_prediction = tf.equal(tf.argmax(y_pred, 1), tf.squeeze(y_o))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))


# In[8]:


loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(
        labels=Y_one_hot_encoder, logits=y_pred
        ))
opt= tf.train.AdamOptimizer(0.001)
gradient=opt.compute_gradients(loss)
train_step=opt.apply_gradients(gradient)


# In[9]:


PCA_comp=[]
Loss_events=[]
sess = tf.Session()

for k in range(8):
    sess.run(tf.global_variables_initializer())
    model_loss=[]
    print("Training Event : {}".format(k + 1))
    trainable_variable=[]
    epochs = 601
    for i, batch in enumerate(tfds.as_numpy(mnist_data.take(epochs))):
        miniBatchX = batch["image"]
        miniBatchY = batch["label"]
        miniBatchY = miniBatchY[:, np.newaxis]
        _, _, acc, l = sess.run(fetches = [train_step, gradient, accuracy, loss], feed_dict = {X_input : miniBatchX,
                                                                   y_o : miniBatchY, lr : 0.01})
        if(i%2==0):
            trainable = sess.run(fetches = tf.trainable_variables())

            trainable_variable.append(trainable)

        model_loss.append(l)
        if i % 50 == 0:
            print("Epochs: {}/{}, Loss: {}, Accuracy: {}".format(i, epochs - 1, l, acc))

    weights_per_epoch = []
    for epoch_weights in trainable_variable:
        weights = []
        for layers in epoch_weights:
            weights.extend(np.reshape(layers, -1))
        weights_per_epoch.append(weights)
    pca = PCA(n_components=2)
    pca.fit(weights_per_epoch)
    reduced = pca.transform(weights_per_epoch)
    PCA_comp.append(reduced)
    Loss_events.append(model_loss)



plt.figure(figsize=(10,10))
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")

for epoch_loss, reduced in zip(Loss_events, PCA_comp):
    plt.plot(reduced[:, 0], reduced[:, 1], '-')
    for i in range(0,len(reduced),10):
        plt.annotate("{:.2f}".format(epoch_loss[i*2]), (reduced[i,0], reduced[i,1]))
plt.show()
